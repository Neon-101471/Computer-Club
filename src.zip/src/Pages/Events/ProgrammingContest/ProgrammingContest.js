import React from 'react';

const ProgrammingContest = () => {
    return (
        <div>
            <h1>Programming contest</h1>
        </div>
    );
};

export default ProgrammingContest;