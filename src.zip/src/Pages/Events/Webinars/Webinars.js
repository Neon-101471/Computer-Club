import React from 'react';

const Webinars = () => {
    return (
        <div>
            <h2>Webinars</h2>
        </div>
    );
};

export default Webinars;