import React from 'react';

const Seminar = () => {
    return (
        <div>
            <h2>Seminar</h2>
        </div>
    );
};

export default Seminar;