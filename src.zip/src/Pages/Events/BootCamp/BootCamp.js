import React from 'react';

const BootCamp = () => {
    return (
        <div>
            <h2>Boot Camp</h2>
        </div>
    );
};

export default BootCamp;