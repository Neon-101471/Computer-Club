import React from 'react';

const WorkShop = () => {
    return (
        <div>
            <h2>WorkShop</h2>
        </div>
    );
};

export default WorkShop;