const firebaseConfig = {
    apiKey: "AIzaSyAIaaK8MPUIkiSZuit3hXjkPjc1yJlym2Q",
    authDomain: "computer-club-10.firebaseapp.com",
    projectId: "computer-club-10",
    storageBucket: "computer-club-10.appspot.com",
    messagingSenderId: "522525509926",
    appId: "1:522525509926:web:c77e0455bf9ad00cd799e7"
  };

  export default firebaseConfig;